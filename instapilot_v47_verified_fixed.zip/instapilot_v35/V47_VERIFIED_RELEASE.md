# InstaPilot V47 — Verified Release

این نسخه بر پایه V46 ساخته شده و یک خطای بحرانی Frontend که باعث می‌شد فقط صفحه رنگی نمایش داده شود برطرف شده است.

## Fixes
- تعریف دوباره `finalizeLayout()` که در V46 از فایل runtime حذف شده بود و باعث توقف کامل `boot()` می‌شد.
- فعال‌سازی واقعی Demo بدون ورود به Backend.
- جلوگیری از تداخل Session/Notification polling با Demo.
- حفظ حالت Demo هنگام جابه‌جایی بین بخش‌ها.
- برگرداندن handlerهای Mission / Blueprint / Scheduler که در runtime قدیمی وجود داشتند ولی در runtime واحد جدید از دست رفته بودند.
- اصلاح جریان V17: `mission/start` سپس `mission/plan` با `mission_id`.
- فعال‌سازی Publish/Sync/Mission/Scheduler handlers.
- اصلاح idle activity guard تا polling پس‌زمینه تایمر عدم فعالیت را بی‌دلیل reset نکند.
- حفظ V40/V41/V42/V43/V45 features.
- PHP 8.4+ target.

## Verification performed
- JavaScript syntax check: PASS (`node --check`)
- PHP syntax checks for index, API router, bootstrap and all backend libraries/worker: PASS
- Duplicate HTML id scan: PASS
- Single CSS runtime reference: PASS
- Single app JS runtime reference: PASS
- Local PHP 8.4 server: PASS
- `/ins/api/health`: HTTP 200
- `/ins/api/auth/csrf`: HTTP 200

## Deployment
Upload the contents of this package to `/ins` and keep `config.php` populated with the real database/Meta/AI configuration.
