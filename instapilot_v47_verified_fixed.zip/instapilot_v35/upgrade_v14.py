from pathlib import Path
p=Path('/mnt/data/v14work/instapilot_final.html')
s=p.read_text()
css=r'''
/* ================= V14 DECISION + LUXURY CONTROL SYSTEM ================= */
:root{--buttonRadius:18px;--buttonDepth:0 10px 0 rgba(0,0,0,.20),0 18px 34px -16px var(--glow)}
button{appearance:none;-webkit-appearance:none}
.primary,.secondary,.miniPrimary,.logoutFull,.kpiRange,.miniTab,.themeCard,.action,.bottom button,.round,.closeBtn,.switch,.commandItem{position:relative;overflow:hidden;isolation:isolate;transition:transform .22s var(--ease),box-shadow .22s var(--ease),border-color .22s var(--ease),filter .22s var(--ease);}
.primary,.secondary,.miniPrimary{background:linear-gradient(145deg,var(--accent),var(--accent2));border:1px solid color-mix(in srgb,var(--accent) 55%,#fff 8%);box-shadow:inset 0 2px 0 #fff8,inset 0 -6px 0 #0003,var(--buttonDepth);text-shadow:0 1px 2px #0006}
.primary:before,.secondary:before,.miniPrimary:before,.action:before,.themeCard:before,.bottom button:before,.kpiRange:before,.miniTab:before,.logoutFull:before,.round:before,.commandItem:before{content:"";position:absolute;inset:-2px;background:linear-gradient(115deg,transparent 18%,#fff5 43%,transparent 58%);transform:translateX(-120%);transition:transform .65s ease;pointer-events:none;z-index:-1}
.primary:hover,.secondary:hover,.miniPrimary:hover,.action:hover,.themeCard:hover,.bottom button:hover,.kpiRange:hover,.miniTab:hover,.logoutFull:hover,.round:hover,.commandItem:hover{transform:translateY(-3px);filter:saturate(1.12)}
.primary:hover:before,.secondary:hover:before,.miniPrimary:hover:before,.action:hover:before,.themeCard:hover:before,.bottom button:hover:before,.kpiRange:hover:before,.miniTab:hover:before,.logoutFull:hover:before,.round:hover:before,.commandItem:hover:before{transform:translateX(120%)}
.primary:active,.secondary:active,.miniPrimary:active,.action:active,.themeCard:active,.bottom button:active,.kpiRange:active,.miniTab:active,.logoutFull:active,.round:active,.commandItem:active{transform:translateY(1px) scale(.98)}
.miniPrimary{min-height:44px;padding:11px 16px;border-radius:15px;color:#fff;font-weight:900}
.action,.kpiRange,.miniTab,.themeCard{border-color:color-mix(in srgb,var(--accent) 18%,var(--line));box-shadow:inset 0 1px #fff2,0 12px 26px -20px var(--accent)}
.action.active,.kpiRange.active,.miniTab.active,.themeCard.active{border-color:color-mix(in srgb,var(--accent) 62%,#fff 4%);box-shadow:inset 0 2px #fff4,inset 0 -5px #0003,0 15px 30px -16px var(--accent);}
.themeGrid{gap:12px!important}.themeCard{min-height:142px!important;background:linear-gradient(145deg,color-mix(in srgb,var(--panel2) 92%,transparent),color-mix(in srgb,var(--surface2) 88%,transparent))!important;color:var(--text);text-align:right;border:1px solid var(--line)!important;border-radius:20px!important;padding:10px!important;box-shadow:inset 0 1px #fff2,0 16px 34px -24px var(--glow)!important}.themeCard .themePreview{height:62px!important;border-radius:15px!important;box-shadow:inset 0 2px #fff4,inset 0 -5px #0004,0 10px 20px -14px var(--glow);position:relative;overflow:hidden}.themeCard .themePreview:after{content:"";position:absolute;inset:0;background:linear-gradient(125deg,#fff4,transparent 32% 72%,#0003)}.themeCard i{background:linear-gradient(145deg,var(--accent),var(--accent2))!important;box-shadow:inset 0 1px #fff8,0 7px 15px -8px var(--accent)!important}
.switch{width:48px!important;height:28px!important;border:1px solid var(--line)!important;background:linear-gradient(145deg,#ffffff12,#0002)!important;box-shadow:inset 0 2px #fff2,inset 0 -4px #0004,0 8px 18px -14px #000!important}.switch.on{background:linear-gradient(145deg,var(--accent),var(--accent2))!important;box-shadow:inset 0 2px #fff7,inset 0 -4px #0004,0 10px 20px -12px var(--accent)!important}.switch i{box-shadow:0 3px 7px #0005,inset 0 1px #fff!important}
.bottom{background:linear-gradient(180deg,transparent,color-mix(in srgb,var(--bg2) 94%,transparent) 28%,color-mix(in srgb,var(--bg) 98%,transparent))!important;border-top:1px solid color-mix(in srgb,var(--accent) 18%,transparent)}
.bottom button{background:linear-gradient(145deg,color-mix(in srgb,var(--panel2) 80%,transparent),color-mix(in srgb,var(--panel) 40%,transparent))!important;border-color:color-mix(in srgb,var(--accent) 14%,var(--line))!important;box-shadow:inset 0 1px #fff2,inset 0 -5px #0003,0 12px 28px -20px var(--glow)!important}.bottom button .bi{background:linear-gradient(145deg,var(--accent),var(--accent2))!important;box-shadow:inset 0 2px #fff8,inset 0 -5px #0004,0 10px 22px -9px var(--accent)!important}.bottom button:not(.active) .bi{opacity:.72;filter:saturate(.78)}.bottom button.active{border-color:color-mix(in srgb,var(--accent) 55%,#fff 5%)!important;background:linear-gradient(145deg,color-mix(in srgb,var(--accent) 14%,transparent),color-mix(in srgb,var(--accent2) 10%,transparent))!important}
/* V14 Decision Center */
.decisionCard{position:relative;overflow:hidden;background:radial-gradient(circle at 100% 0,color-mix(in srgb,var(--accent2) 18%,transparent),transparent 38%),linear-gradient(145deg,color-mix(in srgb,var(--panel2) 92%,transparent),color-mix(in srgb,var(--surface2) 88%,transparent));border:1px solid color-mix(in srgb,var(--accent) 26%,var(--line));border-radius:24px;padding:17px;box-shadow:inset 0 1px #fff3,0 25px 55px -34px var(--accent)}
.decisionHead{display:flex;align-items:center;gap:11px}.decisionOrb{width:46px;height:46px;border-radius:16px;display:grid;place-items:center;background:linear-gradient(145deg,var(--accent),var(--accent2));box-shadow:inset 0 2px #fff8,inset 0 -6px #0004,0 14px 28px -12px var(--accent);transform:perspective(80px) rotateX(5deg)}
.decisionGrid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:13px 0}.decisionMetric{padding:11px;border-radius:15px;background:#ffffff06;border:1px solid var(--line);box-shadow:inset 0 1px #fff2}.decisionMetric b{display:block;font:900 16px Manrope,sans-serif}.decisionMetric small{display:block;color:var(--muted);font-size:8px;margin-top:3px}.decisionReason{margin-top:10px;padding:12px;border-radius:15px;background:linear-gradient(145deg,color-mix(in srgb,var(--accent) 9%,transparent),transparent);border:1px dashed color-mix(in srgb,var(--accent) 28%,transparent);color:var(--muted);font-size:10px;line-height:1.9}.decisionFactors{display:grid;gap:7px;margin-top:10px}.factorRow{display:grid;grid-template-columns:88px 1fr 48px;gap:8px;align-items:center;font-size:9px;color:var(--muted)}.factorBar{height:7px;border-radius:99px;background:#ffffff0a;overflow:hidden;border:1px solid #fff1}.factorBar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent2));box-shadow:0 0 12px color-mix(in srgb,var(--accent) 45%,transparent)}
@media(max-width:650px){.decisionGrid{grid-template-columns:1fr 1fr}.factorRow{grid-template-columns:78px 1fr 42px}.themeGrid{grid-template-columns:1fr 1fr!important}.bottom button{min-height:66px!important}.bottom button span:last-child{font-size:8px!important}.primary,.secondary{min-height:50px}.actionGrid{grid-template-columns:1fr 1fr!important}}
@media(max-width:390px){.bottom{gap:5px;padding-inline:6px}.bottom button{border-radius:17px!important;padding-inline:2px!important}.bottom button .bi{width:38px!important;height:34px!important}.themeGrid{gap:8px!important}}
'''
marker='</style>'
idx=s.find(marker)
s=s[:idx]+css+s[idx:]
# Insert Decision Center before closing AI section (the first </section> after view-ai)
needle=' <div class="card v10ContentEngine"'
start=s.find(needle)
section_end=s.find('</section>', start)
block=r'''
<div class="sectionTitle"><div class="cube" style="--c1:var(--accent);--c2:var(--accent2)"></div><div><h3>AI Decision Center</h3><small>تبدیل داده، Attribution و Memory به تصمیم قابل توضیح</small></div></div>
<div class="decisionCard" id="decisionCenter">
  <div class="decisionHead"><div class="decisionOrb" id="decisionOrb"></div><div><b style="font-size:13px">Next Best Action</b><small style="display:block;color:var(--muted);font-size:9px;margin-top:3px">پیشنهاد بعدی AI بر اساس داده‌های واقعی موجود</small></div></div>
  <div class="decisionGrid"><div class="decisionMetric"><b id="decisionConfidence">—</b><small>Confidence</small></div><div class="decisionMetric"><b id="decisionSamples">—</b><small>Samples</small></div><div class="decisionMetric"><b id="decisionBaseline">—</b><small>Baseline</small></div></div>
  <div class="result" id="decisionAction">برای دریافت تصمیم، روی «به‌روزرسانی تصمیم AI» بزنید.</div>
  <div class="decisionFactors" id="decisionFactors"></div>
  <div class="decisionReason" id="decisionReason">AI برای هر پیشنهاد، دلیل و سطح اطمینان را نمایش می‌دهد.</div>
  <button class="miniPrimary" id="refreshDecision" style="width:100%;margin-top:12px"><span class="btnSvg" data-icon="spark"></span> به‌روزرسانی تصمیم AI</button>
</div>
'''
s=s[:section_end]+block+s[section_end:]
# Add a more coherent theme mode card label tweak if present
s=s.replace('Theme Engine</h3><small>پالت و حالت نمایش تمام اجزا را همزمان تغییر می‌دهد','Theme Engine</h3><small>پالت، نور، دکمه‌ها، نمودارها و Glow همزمان تغییر می‌کنند')
# Add icon definitions and JS before end of v3 script (before </script> first after it)
js=r'''
/* ================= V14 ICON + DECISION ENGINE ================= */
(()=>{
 const $=s=>document.querySelector(s);
 const icons={
  spark:`<svg class="luxeIcon" viewBox="0 0 48 48" aria-hidden="true"><path d="m24 4 4.5 15.5L44 24l-15.5 4.5L24 44l-4.5-15.5L4 24l15.5-4.5L24 4Z" fill="currentColor"/><path d="m38 5 1.5 5L44 11.5 39.5 13 38 18l-1.5-5-4.5-1.5 4.5-1.5L38 5Z" fill="#fff" fill-opacity=".9"/></svg>`,
  target:`<svg class="luxeIcon" viewBox="0 0 48 48"><circle cx="24" cy="24" r="17" fill="currentColor"/><circle cx="24" cy="24" r="10" fill="none" stroke="#fff" stroke-width="2" opacity=".85"/><circle cx="24" cy="24" r="3.5" fill="#fff"/><path d="m34 14 5-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>`,
  trend:`<svg class="luxeIcon" viewBox="0 0 48 48"><path d="M8 36 19 25l7 6 14-17" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M32 14h8v8" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 40h32" stroke="currentColor" stroke-width="3" stroke-linecap="round" opacity=".8"/></svg>`,
  shield:`<svg class="luxeIcon" viewBox="0 0 48 48"><path d="M24 5 39 11v11c0 10-6.7 16-15 20C15.7 38 9 32 9 22V11l15-6Z" fill="currentColor"/><path d="m16 24 5 5 11-12" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`
 };
 document.querySelectorAll('[data-icon]').forEach(e=>{const k=e.dataset.icon;if(icons[k])e.innerHTML=icons[k]});
 const orb=$('#decisionOrb');if(orb)orb.innerHTML=icons.target;
 const cube=$('#view-ai .sectionTitle:last-of-type .cube');if(cube && !cube.querySelector('svg'))cube.innerHTML=icons.target;
 const api=(path,opt={})=>fetch('/ins/api/'+path,{credentials:'same-origin',headers:{'Content-Type':'application/json',...(opt.headers||{})},...opt}).then(r=>r.json());
 function renderDecision(d){
   if(!d)return;
   $('#decisionConfidence').textContent=(d.confidence??0)+'%';
   $('#decisionSamples').textContent=d.sample_count??0;
   $('#decisionBaseline').textContent=(d.baseline??0).toFixed(2)+'%';
   $('#decisionAction').innerHTML='<b style="font-size:15px">'+(d.recommendation?.title||'تصمیم جدید آماده است')+'</b><br><span style="color:var(--muted);font-size:10px">'+(d.recommendation?.summary||'')+'</span>';
   $('#decisionReason').textContent=d.recommendation?.reason||'دلیل کافی برای تصمیم‌گیری ثبت نشده است.';
   const factors=d.factors||[];const host=$('#decisionFactors');host.innerHTML='';factors.slice(0,6).forEach(f=>{const row=document.createElement('div');row.className='factorRow';const lift=Number(f.lift_pct||0);const width=Math.min(100,Math.max(8,Math.abs(lift)*3));row.innerHTML='<span>'+f.factor_key+' / '+f.factor_value+'</span><div class="factorBar"><i style="width:'+width+'%"></i></div><b style="color:'+(lift>=0?'var(--green)':'var(--danger)')+'">'+(lift>=0?'+':'')+lift.toFixed(1)+'%</b>';host.appendChild(row)});
 }
 async function loadDecision(){const box=$('#decisionAction');if(!box)return;box.textContent='در حال تحلیل Attribution و Memory…';try{const r=await api('decision/next');if(!r.ok)throw new Error(r.message||'خطا');renderDecision(r.decision)}catch(e){box.textContent='داده کافی برای تصمیم‌گیری وجود ندارد یا API در دسترس نیست.'}}
 $('#refreshDecision')?.addEventListener('click',async()=>{const b=$('#refreshDecision');b.disabled=true;b.innerHTML='⟳ در حال بازسازی تصمیم…';try{const r=await api('decision/rebuild',{method:'POST',body:'{}'});if(r.ok)renderDecision(r.decision);else $('#decisionAction').textContent=r.message||'داده کافی نیست.'}finally{b.disabled=false;b.innerHTML='<span class="btnSvg"></span> به‌روزرسانی تصمیم AI'}});
 loadDecision();
})();
'''
# insert before final </script>
last=s.rfind('</script>')
s=s[:last]+js+s[last:]
p.write_text(s)
