# InstaPilot V41 — Intelligence Core

Adds Forecast, Trend Radar, Competitor Lab and Experiment Center.

Migration: `instapilot_backend/database/migration_v41_intelligence_core.sql`

The intelligence layer uses first-party account data and explicit hypotheses; it does not claim access to Instagram's private ranking formula or guarantee Explore placement. Meta publicly documents recommendation eligibility and ranking system transparency, including recommendation guidelines and system cards.
