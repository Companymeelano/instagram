# InstaPilot V44 — Auth & Notification Core

## Frontend
- `assets/js/app.js` is the only authoritative application runtime.
- Added session restoration with `GET /auth/session`.
- CSRF 419 automatically refreshes the token and retries once.
- Login updates the active CSRF token returned by the server.
- Logout clears the session and resets notification state.
- Notification center loads authenticated data, supports per-item read and read-all, and no longer hides 401 errors behind Demo content.

## Backend
- Session cookie path is explicitly `/ins`.
- HTTPS is detected directly and through `X-Forwarded-Proto`.
- Session ID + CSRF token rotate on login/register.
- Added `auth/session`, `notifications/unread`, and `notifications/read-all`.
- Notification records are always scoped to the authenticated user.
- API version reports V44.
