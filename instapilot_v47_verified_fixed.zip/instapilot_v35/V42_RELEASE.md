# InstaPilot V42 — Data & Recommendation Engine

V42 extends V41 with a closed-loop first-party data layer.

## Included
- Official Instagram media + Insights synchronization using the existing encrypted account token.
- Normalized performance snapshots and content records.
- Content prediction using the account's historical performance plus content-quality review.
- Recommendation Readiness Gate for originality, quality and safety signals.
- Smart Calendar slots derived from historical performance windows.
- Attribution ledger connecting content outcomes to measurable factors.
- Learning loop: verified performance is fed into the existing learning engine.
- Sync history and status.
- Demo-safe UX: the interface remains usable without a connected Instagram account.

## Important boundary
V42 does **not** claim access to Instagram's private ranking formula and does not guarantee Explore/Reels distribution. The readiness gate is an internal decision aid based on first-party data and public platform guidance.

## Database
Run:
`instapilot_backend/database/migration_v42_data_recommendation_engine.sql`

The migration is idempotent.

## Security
No real API keys are included. Keep Instagram/Meta credentials and AI keys server-side and rotate any credentials that were previously exposed in chat or source files.
