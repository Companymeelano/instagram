# InstaPilot V35 — cPanel / PHP 8.4+

## 1) Upload
Upload the contents of this folder into:
`public_html/ins/`

The entry file must be exactly:
`public_html/ins/index.php`

Do not keep another `index.html` or an older `instapilot_final.html` in the same public folder.

## 2) PHP
Set the domain/subdomain PHP version to **8.4+** in cPanel MultiPHP Manager.
Enable at least: PDO MySQL, cURL, OpenSSL, mbstring, JSON.

## 3) Database
Create a MySQL database/user in cPanel. Import:
`instapilot_backend/database/install_v19_master.sql`

If your existing database already contains part of the schema, use the supplied migrations only when required; do not blindly mix old version SQL files.

## 4) Config
Copy/edit:
`instapilot_backend/config/config.example.php` → `config.php`

Set:
- database host/name/user/password
- `base_url` = `https://YOUR-DOMAIN/ins`
- a random 32+ byte `encryption_key`
- AI provider keys only in Backend config / system_settings
- Instagram App ID/Secret/Redirect URI when Meta OAuth is ready

Never put API keys in JavaScript, HTML, Git, or screenshots.

## 5) Verify
Open:
`https://YOUR-DOMAIN/ins/`

Then test:
`https://YOUR-DOMAIN/ins/api/health`

Expected JSON contains `ok:true`, `php_ok:true` on PHP 8.4+, and database status.

## 6) Important V35 change
Only `assets/js/app.js` is loaded. Older conflicting JS bundles are not loaded. This prevents duplicate click handlers and malformed legacy calls such as `/ins/apiapprovals`.

## V41 Intelligence Core
After the V40 migration, run `instapilot_backend/database/migration_v41_intelligence_core.sql` once. It is idempotent and does not delete existing data.
