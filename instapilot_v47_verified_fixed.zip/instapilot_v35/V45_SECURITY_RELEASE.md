# InstaPilot V45 — Security & Realtime

- Unified Auth Guard with server-side device-session validation
- Idle timeout: 30 minutes; absolute timeout: 24 hours
- Device Sessions: list, revoke individual device, revoke all other devices
- Login Activity audit trail
- Login rate limiting: 8 attempts / 5 minutes per IP bucket
- Realtime-compatible notification polling every 15 seconds with unread badge sync
- CSRF rotation and 419 retry retained
- Revoked-device and expired-session responses force frontend logout
- Shared-hosting friendly; no WebSocket daemon required

Run `instapilot_backend/database/migration_v45_auth_guard.sql` after V44.
