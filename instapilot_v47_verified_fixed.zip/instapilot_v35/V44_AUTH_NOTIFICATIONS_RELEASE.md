# InstaPilot V44 — Authentication & Notifications Hardening

- `assets/js/app.js` is now the single authoritative frontend runtime.
- Session cookie path is explicitly `/ins`, with secure handling behind HTTPS/proxies.
- Added `GET /auth/session` for reliable session restoration after refresh.
- Login/register rotate session ID and CSRF token.
- Logout expires the session cookie cleanly.
- 419 CSRF errors are retried once by the frontend.
- Notifications require authentication, support per-item read and read-all.
- Notification UI no longer masks authentication failures as Demo data.
